"""Estudo independente: lê dados originais, sem importar o otimizador do projeto."""
from pathlib import Path
import os
os.environ.setdefault('MPLCONFIGDIR', '/private/tmp/minerva_optimizer_mpl')
import json, time
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.optimize import milp, Bounds, LinearConstraint, brentq
from scipy.sparse import lil_matrix

ROOT = Path('/Users/ngodeny/Documents/mestrado/202602-resolucao_problemas')
OUT = Path('/private/tmp/minerva_optimizer_study')
OUT.mkdir(exist_ok=True)
training = pd.read_csv(ROOT/'data/processed/minerva_modelagem_treino.csv',parse_dates=['data']).sort_values('data')
raw = pd.read_excel(ROOT/'data/raw/instance_desafio_minerva.xlsx',sheet_name='base_dados')
targets = pd.read_excel(ROOT/'data/raw/instance_desafio_minerva.xlsx',sheet_name='meta_vol_variacao_preco')
# Dados futuros utilizados exclusivamente para definir as datas do horizonte.
dates = pd.to_datetime(raw.loc[raw.Data > training.data.max(),'Data']).to_numpy()
N = len(dates)
assert N == 10 and len(targets) == 2
days = pd.DatetimeIndex(dates).dayofweek.to_numpy()
X = pd.DataFrame({'const':1.,'ln_preco':np.log(training.preco_kg),
                  'sexta':(training.dia_semana=='Sexta').astype(float),
                  'fds':training.dia_semana.isin(['Sábado','Domingo']).astype(float)})
MODEL = sm.OLS(np.log(training.volume_kg),X).fit()
BETA = float(MODEL.params.ln_preco)
SMEAR = float(np.exp(MODEL.resid).mean())
LOG_A = np.log(SMEAR)+float(MODEL.params['const'])+np.where(days==4,float(MODEL.params.sexta),0.)
LOG_A += np.where(days>=5,float(MODEL.params.fds),0.)
P0 = float(training.preco_kg.iloc[-1])
# Premissa de custo, não previsão escolhida por testes: último custo unitário conhecido.
COST = float(training.custo_kg.iloc[-1])
TAX = .07  # Alíquota sobre receita explicitamente definida pelo usuário.
M = targets['Meta (kg)'].to_numpy(float)
WEEK = np.arange(N)//5
groups = np.where(days<4,'Segunda_a_Quinta',np.where(days==4,'Sexta','Fim_de_semana'))
historical_groups = np.where(training.dia_semana.isin(['Segunda','Terça','Quarta','Quinta']),
                             'Segunda_a_Quinta',np.where(training.dia_semana=='Sexta','Sexta','Fim_de_semana'))
limits = training.assign(group=historical_groups).groupby('group').preco_kg.agg(['min','max'])
LOW = np.array([limits.loc[g,'min'] for g in groups])
HIGH = np.array([limits.loc[g,'max'] for g in groups])


def volume(prices):
    return np.exp(LOG_A+BETA*np.log(np.asarray(prices)))


def weekly(prices):
    return np.bincount(WEEK,weights=volume(prices),minlength=2)


def envelopes(delta, opening=None):
    distance=np.abs(np.arange(N)[:,None]-np.arange(N)[None,:])
    lower=np.max(LOW[None,:]-delta*distance,axis=1)
    upper=np.min(HIGH[None,:]+delta*distance,axis=1)
    if opening is not None:
        lower=np.maximum(lower,P0-opening-delta*np.arange(N))
        upper=np.minimum(upper,P0+opening+delta*np.arange(N))
    feasible=bool(np.all(lower<=upper+1e-9))
    return lower,upper,feasible


def minimum_tolerance_bound(delta, opening=None):
    lower,upper,ok=envelopes(delta,opening)
    if not ok:return np.nan
    return max(0.,float(np.max(1-weekly(lower)/M)),float(np.max(weekly(upper)/M-1)))


def solve(delta, tolerance, opening=None, step=.5, seconds=8., gap=.001):
    lower,upper,path_ok=envelopes(delta,opening)
    maxq,minq=weekly(lower),weekly(upper)
    if not path_ok or np.any(maxq < M*(1-tolerance)-1e-7) or np.any(minq > M*(1+tolerance)+1e-7):
        return {'delta':delta,'tolerance':tolerance,'opening':opening,
                'status':'inviavel_por_envelope','max_volume_week_1':maxq[0],
                'max_volume_week_2':maxq[1]}
    # Todas as grades usam uma mesma malha de preços; limites são filtrados por dia.
    global_grid=np.arange(np.ceil(LOW.min()/step)*step,HIGH.max()+step/10,step)
    # Incluir preços constantes de referência fornece testemunhas úteis em fronteiras.
    extra=[]
    for q in [165,165*(1-tolerance),165*(1+tolerance)]:
        extra.append(float(np.exp((np.log(q)-np.log(np.exp(LOG_A[:5]).sum()))/BETA)))
    grid=np.unique(np.r_[global_grid,extra])
    grids=[np.unique(np.r_[grid[(grid>=lower[t]-1e-9)&(grid<=upper[t]+1e-9)],
                               lower[t],upper[t]]) for t in range(N)]
    if any(len(g)==0 for g in grids):
        return {'delta':delta,'tolerance':tolerance,'opening':opening,'status':'sem_grade'}
    offsets=np.r_[0,np.cumsum([len(g) for g in grids])]
    n=int(offsets[-1]); prices=np.concatenate(grids)
    quantities=np.concatenate([np.exp(LOG_A[t]+BETA*np.log(g)) for t,g in enumerate(grids)])
    margin=((1-TAX)*prices-COST)*quantities
    # N escolhas, 2 metas semanais, N-1 variações; abertura já está nos envelopes.
    A=lil_matrix((N+2+N-1,n));lb=[];ub=[]
    for t in range(N):
        A[t,offsets[t]:offsets[t+1]]=1.;lb.append(1.);ub.append(1.)
    for s in range(2):
        for t in np.flatnonzero(WEEK==s):
            A[N+s,offsets[t]:offsets[t+1]]=quantities[offsets[t]:offsets[t+1]]
        lb.append(M[s]*(1-tolerance));ub.append(M[s]*(1+tolerance))
    for t in range(1,N):
        row=N+2+t-1
        A[row,offsets[t]:offsets[t+1]]=grids[t]-P0
        A[row,offsets[t-1]:offsets[t]]=-(grids[t-1]-P0)
        lb.append(-delta);ub.append(delta)
    start=time.monotonic()
    result=milp(-margin/1000.,integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.ones(n)),
                constraints=LinearConstraint(A.tocsr(),np.asarray(lb),np.asarray(ub)),
                options={'time_limit':seconds,'mip_rel_gap':gap})
    row={'delta':delta,'tolerance':tolerance,'opening':opening,
         'status_code':int(result.status),'seconds':time.monotonic()-start,'grid_step':step,
         'max_volume_week_1':maxq[0],'max_volume_week_2':maxq[1]}
    if result.x is None:
        row['status']='inviavel_na_grade' if result.status==2 else 'nao_resolvido'
        return row
    selected=np.array([g[np.argmax(result.x[offsets[t]:offsets[t+1]])] for t,g in enumerate(grids)])
    q=volume(selected);v=weekly(selected)
    assert np.all(v>=M*(1-tolerance)-1e-5) and np.all(v<=M*(1+tolerance)+1e-5)
    assert np.max(np.abs(np.diff(selected)))<=delta+1e-6
    assert opening is None or abs(selected[0]-P0)<=opening+1e-6
    row.update(status='otimo_na_grade' if result.status==0 else 'viavel_com_limite',
               prices=selected.tolist(),volumes=q.tolist(),week_1=float(v[0]),week_2=float(v[1]),
               margin_after_tax=float(np.sum(((1-TAX)*selected-COST)*q)),
               mip_gap=float(getattr(result,'mip_gap',np.nan)),
               price_opening_jump=float(abs(selected[0]-P0)))
    return row


if __name__=='__main__':
    print('MODEL',MODEL.params.to_dict(),'smear',SMEAR,'cost',COST,'p0',P0,flush=True)
    tests=[(30,.05,30),(20,.30,20),(2,.52,2),(2,.30,None)]
    results=[]
    for delta,tol,opening in tests:
        r=solve(delta,tol,opening,seconds=8.)
        results.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
    (OUT/'prototype.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
