from pathlib import Path
import json, base64, html, os
os.environ.setdefault('MPLCONFIGDIR','/private/tmp/minerva_optimizer_mpl')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import brentq
import minerva_optimizer_study as st

out=st.OUT
deltas=np.array([2,4,6,8,10,12,14,16,16.1,18,20,24,27.3,30,35,40],float)
tolerances=np.array([.05,.10,.20,.30,.40,.45,.50,.52,.55,.60])
reuse=os.environ.get('MINERVA_REUSE_RESULTS')=='1'
results=json.loads((out/'sensibilidade_conjunta.json').read_text()) if reuse else []
if not reuse:
    for i,tol in enumerate(tolerances):
        for delta in deltas:
            results.append(st.solve(float(delta),float(tol),float(delta),seconds=4.))
        print(f'mapa {i+1}/{len(tolerances)} completo',flush=True)
(out/'sensibilidade_conjunta.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
df=pd.DataFrame([{k:v for k,v in r.items() if k not in ['prices','volumes']} for r in results])
df.to_csv(out/'sensibilidade_conjunta.csv',index=False)

opening_results=json.loads((out/'sensibilidade_abertura.json').read_text()) if reuse else []
if not reuse:
    for tol in [.05,.30]:
        for opening in [2,10,20,30,40,41.48,50,60,70,72.56,80,90,110]:
            opening_results.append(st.solve(2.,tol,float(opening),seconds=4.))
(out/'sensibilidade_abertura.json').write_text(json.dumps(opening_results,ensure_ascii=False,indent=2))
pd.DataFrame([{k:v for k,v in r.items() if k not in ['prices','volumes']} for r in opening_results]).to_csv(out/'sensibilidade_abertura.csv',index=False)

cases=[('Sem vinculo inicial; tolerancia do PDF',2,.05,None),
       ('Sem vinculo inicial; tolerancia da planilha',2,.30,None),
       ('Somente tolerancia flexibilizada',2,.5201,2),
       ('Somente variacao flexibilizada; planilha',16.1,.30,16.1),
       ('Somente variacao flexibilizada; PDF',27.3,.05,27.3),
       ('Somente abertura flexibilizada; planilha',2,.30,41.48),
       ('Somente abertura flexibilizada; PDF',2,.05,72.56),
       ('Variacao e tolerancia flexibilizadas juntas',8,.45,8)]
selected=json.loads((out/'casos_selecionados.json').read_text()) if reuse else []
if not reuse:
    for name,delta,tol,opening in cases:
        result=st.solve(delta,tol,opening,seconds=8.)
        result['name']=name; selected.append(result)
        print('CASO',name,result['status'],result.get('margin_after_tax'),flush=True)
(out/'casos_selecionados.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2))

# Curvas analíticas: envelopes exatos das trajetórias, antes de impor metas semanais.
fine=np.linspace(0,40,401)
envelopes=[st.envelopes(d,d) for d in fine]
vmax=np.array([st.weekly(lo) for lo,hi,ok in envelopes])
frontier=np.array([st.minimum_tolerance_bound(d,d) for d in fine])
thresholds={}
for tol in [.05,.30]:
    thresholds[str(tol)]={
        'delta_lower_bound':brentq(lambda d:st.minimum_tolerance_bound(d,d)-tol,2,40),
        'opening_lower_bound':brentq(lambda b:st.minimum_tolerance_bound(2,b)-tol,2,110)}

calibration=pd.read_csv(st.ROOT/'reports/tables/021_previsoes_validacao_origens.csv')
calibration=calibration.loc[calibration.candidato=='P3']
weekly_cal=calibration.groupby(['origem','inicio_semana'])[['volume_real_kg','volume_previsto_kg']].sum()
weekly_cal['ratio']=weekly_cal.volume_real_kg/weekly_cal.volume_previsto_kg
weekly_cal.to_csv(out/'incerteza_semanal_validacao.csv')
ratio_min,ratio_max=float(weekly_cal.ratio.min()),float(weekly_cal.ratio.max())
metadata={'coefficients':st.MODEL.params.to_dict(),'beta':st.BETA,'smearing':st.SMEAR,
          'opening_historical_price':st.P0,'cost_assumption':st.COST,'tax_rate':st.TAX,
          'cost_assumption_description':'Ultimo custo unitario conhecido em 31/10, constante; imposto de 7% sobre a receita.',
          'dates':[str(pd.Timestamp(d).date()) for d in st.dates],
          'constant_price_for_165':float(np.exp((np.log(165)-np.log(np.exp(st.LOG_A[:5]).sum()))/st.BETA)),
          'maximum_weekly_volumes_delta2':st.weekly(st.envelopes(2,2)[0]).tolist(),
          'minimum_common_tolerance_delta2':st.minimum_tolerance_bound(2,2),
          'thresholds_analytical_lower_bounds':thresholds,
          'uncertainty_ratio_min':ratio_min,'uncertainty_ratio_max':ratio_max,
          'minimum_tolerance_for_all_empirical_scale_extremes':(ratio_max-ratio_min)/(ratio_max+ratio_min),
          'solver_counts':df.status.value_counts().to_dict(),'price_support_by_context':st.limits.to_dict()}
(out/'metadados.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,2,figsize=(14,5.2))
axs[0].plot(fine,vmax[:,0],label='Semana 1',color='#174d75',lw=2.3)
axs[0].plot(fine,vmax[:,1],label='Semana 2',color='#55937a',lw=2.3)
axs[0].axhline(156.75,color='#9b4f45',ls='--',label='Minimo do PDF: 156,75 kg')
axs[0].axhline(115.5,color='#a87830',ls=':',label='Minimo da planilha: 115,50 kg')
axs[0].axvline(2,color='#737373',ls=':',lw=1)
axs[0].scatter([2,2],metadata['maximum_weekly_volumes_delta2'],color=['#174d75','#55937a'],zorder=5)
axs[0].set(title='Maior volume previsto permitido pela trajetoria de precos',xlabel='Limite de variacao entre registros (R$/kg)',ylabel='Volume semanal maximo previsto (kg)')
axs[0].legend(fontsize=8);axs[0].grid(alpha=.2)
axs[1].plot(fine,100*frontier,color='#174d75',lw=2.3,label='Limite inferior por envelope')
for tol,color in [(.05,'#9b4f45'),(.30,'#a87830')]:
    threshold=thresholds[str(tol)]['delta_lower_bound']
    axs[1].axhline(tol*100,color=color,ls='--',lw=1)
    axs[1].scatter([threshold],[tol*100],color=color,zorder=5)
    axs[1].annotate(f'R$ {threshold:.2f}; {tol:.0%}',(threshold,tol*100),xytext=(8,10),textcoords='offset points',fontsize=9)
axs[1].scatter([2],[100*metadata['minimum_common_tolerance_delta2']],color='#174d75',zorder=5)
axs[1].annotate('R$ 2: tolerancia de aproximadamente 52%',(2,100*metadata['minimum_common_tolerance_delta2']),xytext=(15,8),textcoords='offset points',fontsize=8)
axs[1].set(title='Troca entre limite de preco e tolerancia de volume',xlabel='Limite de variacao entre registros (R$/kg)',ylabel='Menor tolerancia comum necessaria (%)',ylim=(0,65))
axs[1].grid(alpha=.2)
fig.suptitle('Diagnostico da inviabilidade com continuidade desde 31/10',fontsize=14,weight='bold')
fig.text(.01,.015,'Fonte: P3 ajustado em ago-out/2025; horizonte 03-14/nov. A primeira mudanca tambem respeita o limite do eixo x. Envelopes usam o suporte observado.',fontsize=8)
fig.tight_layout(rect=(0,.05,1,.94));fig.savefig(out/'01_fronteira_viabilidade.png',dpi=180);plt.close(fig)

margin=np.full((len(tolerances),len(deltas)),np.nan)
status=np.empty(margin.shape,dtype=object)
for i,tol in enumerate(tolerances):
    for j,delta in enumerate(deltas):
        r=next(r for r in results if abs(r['tolerance']-tol)<1e-10 and abs(r['delta']-delta)<1e-10)
        if 'margin_after_tax' in r:margin[i,j]=r['margin_after_tax']/1000
        status[i,j]=r['status']
fig,ax=plt.subplots(figsize=(13,6))
cmap=plt.get_cmap('YlGnBu').copy();cmap.set_bad('#e5e7e9')
im=ax.imshow(np.ma.masked_invalid(margin),origin='lower',aspect='auto',cmap=cmap)
ax.set_xticks(range(len(deltas)),[f'{d:g}' for d in deltas])
ax.set_yticks(range(len(tolerances)),[f'{t:.0%}' for t in tolerances])
ax.set(xlabel='Variação máxima entre registros e na abertura (R$/kg)',ylabel='Tolerância simétrica em torno de 165 kg/semana',title='Relaxação conjunta: margem prevista após imposto de 7%')
for i in range(len(tolerances)):
    for j in range(len(deltas)):
        if np.isfinite(margin[i,j]):
            color='white' if margin[i,j]>np.nanmedian(margin) else '#173747'
            ax.text(j,i,f'{margin[i,j]:.0f}',ha='center',va='center',fontsize=8,color=color)
        elif status[i,j] not in ['inviavel_por_envelope','inviavel_na_grade']:
            ax.text(j,i,'?',ha='center',va='center')
bar=fig.colorbar(im,ax=ax);bar.set_label('Margem apos imposto de 7% prevista nas duas semanas (mil R$)')
fig.text(.015,.035,'Cinza: inviabilidade provada por envelope. Células coloridas: soluções na malha com gap relativo até 0,1%. Malha de R$ 0,50 + extremos e preços de referência.',fontsize=8)
fig.text(.015,.01,f'Custo de referencia fixo: R$ {st.COST:.2f}/kg; imposto de 7% sobre receita. Curva e custo congelados. Nenhum dado futuro de volume, receita ou custo entra no calculo.',fontsize=8)
fig.tight_layout(rect=(0,.07,1,1));fig.savefig(out/'02_mapa_sensibilidade_conjunta.png',dpi=180);plt.close(fig)

fig,axs=plt.subplots(1,2,figsize=(14,5))
for tol,color in [(.05,'#174d75'),(.30,'#55937a')]:
    r=[r for r in opening_results if r['tolerance']==tol and 'margin_after_tax' in r]
    axs[0].plot([r['opening'] for r in r],[r['margin_after_tax']/1000 for r in r],marker='o',label=f'Tolerancia {tol:.0%}',color=color)
    threshold=thresholds[str(tol)]['opening_lower_bound']
    axs[0].axvline(threshold,color=color,ls=':',lw=1)
    axs[0].text(threshold+.7,.04,f'R$ {threshold:.2f}',transform=axs[0].get_xaxis_transform(),rotation=90,fontsize=8,color=color)
axs[0].set(title='Flexibilizar apenas a primeira mudanca de preco',xlabel='Limite para o salto de abertura (R$/kg)',ylabel='Margem apos imposto de 7% nas duas semanas (mil R$)')
axs[0].legend();axs[0].grid(alpha=.2)
chosen=[r for r in selected if r['name'] in ['Somente variacao flexibilizada; planilha','Somente abertura flexibilizada; planilha','Variacao e tolerancia flexibilizadas juntas']]
for r in chosen:
    if 'prices' in r:axs[1].plot(range(1,11),r['prices'],marker='o',label=r['name'].replace('; planilha',''),lw=1.5)
axs[1].axhline(st.P0,color='#888888',ls=':',label='Preco anterior ao horizonte')
axs[1].axvline(5.5,color='#bbbbbb',lw=.8)
axs[1].set(title='Trajetorias diferentes podem recuperar a viabilidade',xlabel='Registro planejado (1-5: semana 1; 6-10: semana 2)',ylabel='Preco recomendado na simulacao (R$/kg)')
axs[1].legend(fontsize=7);axs[1].grid(alpha=.2)
fig.text(.01,.012,'Fonte: estudo independente com P3; abertura flexibilizada mantem variacao interna de R$ 2. Imposto de 7% sobre receita; custo de referencia fixo.',fontsize=8)
fig.tight_layout(rect=(0,.045,1,1));fig.savefig(out/'03_abertura_e_trajetorias.png',dpi=180);plt.close(fig)

def money(v):return f'{v:,.2f}'.replace(',','X').replace('.',',').replace('X','.')
def img(name,alt):return '<img alt="'+html.escape(alt)+'" src="data:image/png;base64,'+base64.b64encode((out/name).read_bytes()).decode()+'">'
rows=[]
for r in selected:
    rows.append('<tr>'+''.join('<td>'+html.escape(v)+'</td>' for v in [r['name'],f"R$ {r['delta']:.2f}",f"{r['tolerance']:.2%}",
                'Livre' if r['opening'] is None else f"R$ {r['opening']:.2f}",r['status'],
                money(r.get('week_1',float('nan'))),money(r.get('week_2',float('nan'))),money(r.get('margin_after_tax',float('nan'))) ])+'</tr>')
case_table='<div class="scroll"><table><thead><tr><th>Experimento</th><th>Variacao interna</th><th>Tolerancia</th><th>Abertura</th><th>Status na malha</th><th>Semana 1 (kg)</th><th>Semana 2 (kg)</th><th>Margem apos imposto de 7% (R$)</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table></div>'

text='''<!DOCTYPE html><html lang="pt-BR"><meta charset="utf-8"><title>Planejamento do otimizador Minerva</title>
<style>body{font:17px/1.6 system-ui,sans-serif;color:#203343;background:#fff;margin:auto;max-width:1120px;padding:40px 28px}h1{font-size:31px;line-height:1.2}h2{font-size:23px;margin-top:42px}h3{font-size:19px}p,li{max-width:1000px}a{color:#1b6285}img{width:100%;height:auto;margin:14px 0}table{border-collapse:collapse;font-size:13px;line-height:1.4;width:100%}td,th{padding:10px;border-bottom:1px solid #d9e2e7;text-align:right}td:first-child,th:first-child{text-align:left}thead{background:#edf3f6}.scroll{overflow-x:auto}.lead{font-size:20px}.callout{background:#f0f5f7;padding:18px 23px;margin:25px 0;border-left:4px solid #376e8a}.caption,footer{font-size:13px;color:#586c78}.eq{font-family:ui-monospace,monospace;background:#f5f7f8;padding:14px;white-space:normal}code{font-size:.9em}@media print{body{max-width:none;font-size:11pt;padding:0}img{break-inside:avoid}h2{break-after:avoid}.scroll{overflow:visible}table{font-size:8pt}}</style>
<h1>Como construir o otimizador de margem para duas semanas</h1>
<p class="lead">A decisao e uma sequencia de precos. A demanda e calculada pela curva P3 congelada. A analise deve primeiro diagnosticar a viabilidade e, depois, mostrar a margem e o custo comercial de cada flexibilizacao.</p>
<p class="caption">Estudo de planejamento independente, 17/10/2026. Nenhum codigo ou regra do otimizador existente foi utilizado. Notebook de referencia: 2.0.1; dados originais: instance_desafio_minerva.xlsx; enunciado: Minerva_Unifesp_ITA.pdf.</p>
<h2>1. O que o enunciado realmente estabelece</h2>
<p>O PDF confirma: horizonte de duas semanas, preco diario por SKU, maximizacao da margem total, metas semanais com limites inferior e superior e limite de mudanca de preco entre dias consecutivos. A curva de demanda deve ser respeitada.</p>
<p>Ha uma divergencia dentro do proprio PDF: a secao 0.3 fala em tolerancia de 5%; a Figura 5 e a planilha original informam 30%. Para meta de 165 kg, os intervalos sao <strong>156,75 a 173,25 kg</strong> e <strong>115,50 a 214,50 kg</strong>, respectivamente. O estudo conserva as duas instancias e nao escolhe a mais conveniente depois de observar os resultados.</p>
<p>O arquivo tem dez datas de planejamento: 03 a 07 e 10 a 14/nov/2025. Nao foram criados dias adicionais com vendas ficticias. E necessario confirmar como a regra de preco deve atravessar finais de semana: aqui, o limite incide entre os registros comerciais consecutivos. Permitir alteracoes em dias sem venda seria outra especificacao.</p>
<p>O PDF nao explicita a condicao de abertura. Ligar 03/11 ao ultimo preco historico, de 31/10, e uma interpretacao operacional razoavel, mas precisa constar do contrato. Ela nao deve entrar silenciosamente no modelo.</p>
<h2>2. A inviabilidade depende da condicao inicial</h2>
<div class="callout"><strong>Sem a ligacao ao ultimo preco historico, existe uma testemunha de viabilidade:</strong> preco constante de aproximadamente <strong>R$ 1.237,88/kg</strong>, com 165 kg previstos em cada semana e variacao interna zero. Esse preco esta dentro do suporte observado dos grupos usados no horizonte. Portanto, as metas e o limite de variacao interno, sozinhos, nao tornam o problema inviavel.</div>
<p>Com continuidade desde R$ 1.318,9196/kg e limite de R$ 2 por transicao, a trajetoria que mais gera volume reduz o preco tao rapido quanto permitido: R$ 1.316,9196 no primeiro registro, R$ 1.314,9196 no segundo, e assim sucessivamente. Mesmo essa trajetoria produz somente <strong>79,20 kg na primeira semana e 87,05 kg na segunda</strong>. Nenhuma outra trajetoria admissivel consegue volumes maiores, pois a curva e decrescente.</p>
<p>Isso e uma prova de inviabilidade para as duas tolerancias: o maximo atingivel esta abaixo dos minimos exigidos. O conflito e entre <strong>preco inicial alto, velocidade limitada de reducao e meta semanal</strong>. Alterar o modelo preditivo para obrigar a meta a caber distorceria o problema.</p>
<h2>3. Descricao matematica em linguagem de negocio</h2>
<p>Para cada uma das dez datas, escolher um preco por kg. Esse e o vetor de decisao. A partir do preco e do contexto seg-qui, sexta ou fim de semana, a curva P3 calcula o volume esperado. O volume nao e uma segunda decisao livre que possa ser aumentado para fechar a meta.</p>
<div class="eq">Margem total prevista = soma, nos dez dias, de [(0,93 x preco de venda - custo unitario previsto) x volume previsto naquele preco].</div>
<p>O usuario definiu aliquota de <strong>7% sobre a receita</strong>. O imposto e calculado como 0,07 x preco x volume. As margens deste estudo descontam esse imposto e o custo unitario, sem outros custos nao informados. A planilha nao tem a coluna de impostos ilustrada no PDF; a aliquota vem da instrucao explicita do usuario e nao foi inferida dos dados futuros.</p>
<p>Para os exemplos numericos, foi adotado o ultimo custo unitario conhecido em 31/10, R$ 1.010,4468/kg, constante durante o plano. E uma premissa de simulacao transparente, nao uma afirmacao sobre o custo futuro. O otimizador final deve receber uma previsao ex ante ou tabela de custos fornecida pela empresa.</p>
<p>A curva foi ajustada uma vez nos 76 registros de agosto a outubro, com a especificacao selecionada no novo notebook: log(volume) = 91,59146 - 12,36470 x log(preco) - 1,33944 x indicador(sexta) - 2,96701 x indicador(fim de semana). A conversao para kg usa fator de smearing 1,1225969. Nenhum volume, receita ou custo futuro foi usado para ajustar essa curva ou escolher solucoes.</p>
<h2>4. Restricoes que precisam existir e decisoes que precisam ser declaradas</h2>
<ol><li><strong>Metas por semana:</strong> a soma dos cinco volumes previstos de cada semana deve estar entre seu minimo e maximo. Exceder a meta da segunda semana nao compensa falta na primeira.</li>
<li><strong>Variacao interna:</strong> a diferenca absoluta entre dois precos consecutivos planejados nao pode superar o limite. Isso inclui a transicao entre a primeira e a segunda semana.</li>
<li><strong>Abertura:</strong> quando exigida, limitar separadamente a diferenca entre o primeiro preco e o ultimo preco conhecido. O limite pode ser igual ao diario, mas convem parametriza-lo separadamente para estudar uma renegociacao inicial sem liberar os dias seguintes.</li>
<li><strong>Vinculo com a demanda:</strong> o volume deve ser o resultado da curva no preco escolhido e no grupo de calendario correspondente.</li>
<li><strong>Dominio tecnico de precos:</strong> exigir precos positivos e declarar uma faixa em que a curva sera usada. Neste estudo, foram usados os limites historicos de cada grupo, derivados dos dados. Esse e um cuidado de validade preditiva; nao uma restricao comercial escrita no PDF. Extrapolacao, se estudada, deve aparecer em cenario identificado separadamente.</li></ol>
<p>Nao foram acrescentados pisos de margem, estoque, capacidade diaria, desconto, igualdade de precos dentro do grupo ou outras regras do repositorio. O imposto de 7% foi incluido por instrucao do usuario. O agrupamento seg-qui muda a funcao de demanda; ele nao obriga os quatro precos a serem iguais.</p>
<h2>5. Como resolver de forma auditavel</h2>
<p><strong>Etapa A: testar a compatibilidade dos limites de preco.</strong> Propagar as faixas de cada dia e as variacoes admitidas para frente e para tras. Assim se verifica se existe alguma trajetoria de precos, antes de discutir volumes.</p>
<p><strong>Etapa B: construir envelopes de volume.</strong> A menor trajetoria admissivel de precos fornece o maior volume previsto; a maior fornece o menor. Se uma semana nao consegue atingir seu minimo ou nao consegue ficar abaixo do maximo, a inviabilidade esta provada. Se os intervalos se cruzam, ainda se verifica a viabilidade conjunta, porque as semanas compartilham a transicao de preco.</p>
<p><strong>Etapa C: resolver as duas semanas juntas.</strong> Para apenas dez dias, recomendo uma malha de precos e programacao inteira mista: escolher um preco por dia entre alternativas; deixar pre-calculados volume e margem de cada alternativa; impor metas e variacoes como restricoes lineares. Essa formulacao gera um limite de qualidade da solucao na malha e distingue inviabilidade de interrupcao do algoritmo.</p>
<p>O prototipo independente usa <code>scipy.optimize.milp</code>, malha base de R$ 0,50 acrescida dos extremos de trajetoria e de precos constantes de referencia. A funcao de demanda e calculada exatamente em cada ponto; a aproximacao esta apenas nos precos disponiveis. Os resultados e o gap estao nos arquivos tabulares. A implementacao definitiva deve refinar a malha e recalcular a curva apos arredondar os precos ao centavo.</p>
<p>Uma otimizacao continua pode complementar o estudo, mas encontrar uma solucao com um metodo local nao prova otimalidade global; fracasso de convergencia tambem nao prova inviabilidade. Ha uma verificacao util: sem o limite de variacao entre precos, a curva potencia pode ser invertida e o problema pode ser formulado em volumes. Como a elasticidade em modulo e maior que 1, a margem e concava em volume com custo unitario fixo; essa versao fornece um benchmark global mais simples.</p>
<h2>6. Sensibilidade: qual limite precisa mudar e quanto</h2>
<p>As familias de experimentos devem ser definidas antes de olhar a maior margem: (a) mudar somente a tolerancia ou o minimo de volume; (b) mudar somente o limite de variacao diaria, incluindo a abertura quando os limites forem vinculados; (c) mudar somente a abertura, mantendo R$ 2 nos dias seguintes; (d) combinar variacao e tolerancia; e (e) combinar abertura e tolerancia quando fizer sentido comercial. Os coeficientes preditivos e as premissas de custo ficam congelados em todas as combinacoes.</p>
'''+img('01_fronteira_viabilidade.png','Limites de volume e fronteira entre variacao de preco e tolerancia')+'''
<ul><li><strong>Manter variacao de R$ 2:</strong> o limite inferior de volume precisa cair para 79,20 kg na primeira semana. Uma tolerancia simetrica comum precisaria chegar a aproximadamente 52%, contra 30% da planilha ou 5% do texto. Pode ser mais claro negociar um deficit permitido em kg por semana em vez de aumentar simultaneamente minimo e maximo.</li>
<li><strong>Manter a tolerancia de 30%:</strong> a variacao comum precisa chegar a aproximadamente R$ 16,10 por transicao para recuperar a viabilidade central. Para 5%, cerca de R$ 27,27. Os exemplos proximos dessa fronteira foram verificados conjuntamente pelo prototipo.</li>
<li><strong>Manter R$ 2 dentro do horizonte e flexibilizar apenas a abertura:</strong> o salto inicial precisa ser de aproximadamente R$ 41,48 para tolerancia de 30%, ou R$ 72,56 para 5%. Isso preserva estabilidade nos dias seguintes e e uma negociacao comercial diferente de permitir grandes saltos todos os dias.</li></ul>
<p>Esses numeros sao condicionais a curva central, ao calendario de dez registros e ao vinculo com o preco de 31/10. O primeiro obstaculo e a primeira semana. A recuperacao de viabilidade foi verificada com os dois limites de cada semana, e nao somente aumentando o volume agregado das duas semanas.</p>
'''+img('02_mapa_sensibilidade_conjunta.png','Mapa de relaxacao conjunta e margem apos imposto de 7% prevista')+'''
<p>O mapa mostra quais combinacoes deixam de ser inviaveis e a margem obtida em cada uma. Comparar somente os valores coloridos nao basta: uma margem maior pode ter sido comprada com uma permissao comercial muito maior. A selecao deve mostrar tambem o limite alterado e a magnitude da alteracao.</p>
'''+case_table+img('03_abertura_e_trajetorias.png','Sensibilidade da abertura e trajetorias de precos')+'''
<p>O caso conjunto de R$ 8 de variacao e tolerancia de 45% ilustra a interacao: os dois limites sao alterados parcialmente. Ele deve ser comparado com alterar apenas um deles, e nao apresentado como se ainda respeitasse a instancia nominal.</p>
<h2>7. Como escolher entre flexibilizacoes sem arbitrariedade</h2>
<p>Primeiro, identificar solucoes nao dominadas: uma alternativa e dominada se outra exigir flexibilizacao nao maior em nenhuma dimensao e oferecer margem pelo menos igual. A fronteira de Pareto apresenta os acordos comerciais relevantes. Nao somar automaticamente reais de mudanca de preco e quilos de deficit; essas unidades nao sao comparaveis.</p>
<p>Para uma familia com somente uma regra flexibilizada, usar duas etapas: minimizar a alteracao necessaria para recuperar a viabilidade; depois, fixar essa alteracao e maximizar margem. Quando varias regras podem mudar, usar limites explicitos em cada eixo e apresentar a fronteira, ou usar pesos somente se a empresa fornecer os custos ou prioridades dessas violacoes. A penalidade nao deve ser escolhida depois para favorecer uma solucao.</p>
<p>O resultado deve informar por semana: volume, limite inferior, limite superior, deficit ou excesso, margem e restricoes ativas. Por dia: preco, volume previsto, custo usado, margem e variacao frente ao anterior. Inviabilidade deve ser acompanhada de prova ou status do solver; nao deve aparecer como uma agenda de precos que secretamente descumpre as regras.</p>
<h2>8. Incerteza: cumprir na curva nao garante cumprir nas vendas</h2>
<p>O novo notebook registra WMAPE semanal medio de 34,69% para P3 e mediana de erro semanal absoluto de 38,9%. Apenas 3 das 12 previsoes semanais ficaram dentro de 30%. Sao 12 previsoes de sete semanas distintas em origens sobrepostas, nao 12 semanas independentes. Isso limita a precisao de qualquer afirmacao probabilistica.</p>
<p>Nos dados de validacao, a razao volume real/previsto varia de aproximadamente <strong>0,668 a 1,828</strong>. Usar esses extremos como teste de estresse nao cria um intervalo de confianca: apenas pergunta se o plano resistiria a desvios ja vistos no desenvolvimento. Os choques devem ser semanais, preservando a variacao conjunta entre dias, em vez de ruidos diarios independentes que se cancelam artificialmente.</p>
<p>Ha um conflito estrutural adicional: para garantir a faixa de 30% tanto no fator baixo quanto no alto, o volume central precisaria ser ao menos <strong>172,96 kg</strong> e ao mesmo tempo no maximo <strong>117,34 kg</strong>. Portanto, robustez contra todos esses extremos seria impossivel mesmo com precos totalmente livres. A tolerancia simetrica precisaria ser de pelo menos 46,49% para deixar de haver essa contradicao, antes das demais restricoes. Isso nao e uma recomendacao de tolerancia; e um diagnostico do custo de exigir protecao extrema com esta amostra.</p>
<p>Recomendo um plano central e uma tabela de estresse: deficit, excesso e margem sob choques semanais, custo e elasticidade alternativos. Depois, se a empresa definir seu nivel de risco, pode-se formular margem esperada, pior caso ou penalidade por falta/excesso. Chance constraints exigiriam distribuicoes e probabilidades que a amostra atual nao sustenta com precisao.</p>
<p>Ao variar a elasticidade, preservar o volume de referencia em um preco-pivo e mudar a inclinacao em torno dele. Trocar apenas o coeficiente do log-preco com intercepto fixo deslocaria artificialmente toda a curva. O notebook sugere examinar modulos entre aproximadamente 7 e 16; a faixa deve ser tratada como cenario de sensibilidade, nao como nova selecao de modelo.</p>
<h2>9. Avaliacao retrospectiva e roteiro de implementacao</h2>
<ol><li><strong>Contrato de entrada:</strong> versao e parametros do P3; calendario; unidade monetaria; meta e tolerancia por semana; limite entre registros; regra de abertura; custo futuro; imposto de 7%; faixa tecnica de precos.</li>
<li><strong>Diagnostico:</strong> envelopes de preco e volume, testemunha de viabilidade quando existir e conflitos identificados quando nao existir.</li>
<li><strong>Otimizacao nominal:</strong> procurar uma sequencia que respeite o contrato; reportar a margem condicional e o certificado numerico disponivel.</li>
<li><strong>Estudo de flexibilizacao:</strong> grade de parametros predefinida, menor alteracao por familia e alternativas de Pareto com unidades explicitas.</li>
<li><strong>Estresse preditivo e economico:</strong> manter a mesma sequencia de precos e reavaliar seus volumes e margens nos cenarios. Reotimizar separadamente informa o valor de uma adaptacao, mas nao mede a robustez do plano originalmente escolhido.</li>
<li><strong>Avaliacao nas duas semanas reservadas:</strong> congelar o plano antes de olhar vendas ou custos futuros. Calcular os resultados reais da politica historica e avaliar previsoes nos precos historicos. A margem que seria realizada sob outros precos nao foi observada; deve ser chamada de margem simulada, condicional a curva, e nao de ganho real comprovado.</li>
<li><strong>Entrega:</strong> agenda diaria, resumo por semana, mapa de viabilidade, curvas de margem e flexibilizacao, cenarios de risco, status/gap, premissas e limitacoes.</li></ol>
<p>A curva e observacional: boas previsoes nao identificam, por si, um efeito causal de mudar precos. O otimizador fornece a melhor decisao segundo esse modelo, sob as premissas declaradas. O uso operacional deve preservar acompanhamento dos desvios e possibilidade de replano com novos dados.</p>
<h2>10. Decisoes necessarias antes do otimizador definitivo</h2>
<ul><li>Qual tolerancia e oficial: 5% do texto ou 30% da Figura 5/planilha?</li><li>A primeira mudanca deve respeitar R$ 2 a partir de 31/10? Ha permissao de um ajuste inicial separado?</li><li>O limite vale entre datas comerciais ou por dia de calendario, com alteracoes possiveis nos fins de semana?</li><li>Qual previsao de custo unitario deve ser usada antes do inicio do horizonte? O imposto adotado e 7% sobre receita.</li><li>Qual flexibilizacao e comercialmente aceitavel e qual nivel de risco de deficit/excesso pode ser tolerado?</li></ul>
<p>As escolhas acima sao de contrato e operacao. Elas podem ser resolvidas mantendo o P3 escolhido; nao exigem reabrir a competicao entre modelos.</p>
<footer><p>Fontes: PDF Minerva_Unifesp_ITA, secao 0.3 e Figuras 3-5; planilha original, abas base_dados e meta_vol_variacao_preco; notebook 2.0.1 e previsoes 021_previsoes_validacao_origens.csv; base de desenvolvimento ate 31/10. Os scripts deste estudo nao importam src/optimization nem os documentos de regras existentes. Os resultados completos, status e gaps estao nos JSON/CSV adjacentes.</p></footer></html>'''
(out/'analise_e_plano_otimizador.html').write_text(text,encoding='utf-8')
print('RESULTADOS',df.status.value_counts().to_dict(),flush=True)
print('METADADOS',json.dumps(metadata,ensure_ascii=False),flush=True)
print('RELATORIO',out/'analise_e_plano_otimizador.html',flush=True)
